# AURA 1.6.4 — Build Status

## Source validation
- Kotlin core compilation: PASS (validated with local kotlinc).
- Android project structure: PASS.
- Duplicate `Theme.Aura` resource: resolved.
- CI workflow: configured for JDK 17, Android SDK 35, Gradle 8.9.

## Actual Android binary status
APK/AAB have **not** been claimed as built in this environment because this runtime has no installed Gradle, Android SDK, or ADB, and outbound package download is unavailable.

The repository is therefore configured for a reproducible external Android build rather than falsely marking a binary as verified.

## CI build sequence
1. `gradle projects`
2. `gradle test`
3. `gradle lint`
4. `gradle assembleRelease`
5. `gradle bundleRelease`
6. upload APK/AAB artifacts

## Local build
Run `tools/local-build.sh` on a machine with Gradle 8.9+, JDK 17, and Android SDK 35.


## 1.6.4 hardening
- Application versionCode/versionName synchronized to 1.6.4.
- CI uses Gradle Actions rather than assuming a preinstalled Gradle binary.
- Android binary remains unverified in this execution environment because Android SDK/Gradle/ADB are unavailable.
