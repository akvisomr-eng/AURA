package com.aura.core.agent

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AgentRuntimeTest {
    @Test fun selectsRequiredCapabilities() {
        val registry = AgentRegistry()
        registry.register(AgentDescriptor("vision", setOf(Capability("vision"))))
        registry.register(AgentDescriptor("general", setOf(Capability("vision"), Capability("reasoning")), priority = 1))
        val selected = registry.select(AgentRequest("t", "inspect", setOf("vision", "reasoning")))
        assertNotNull(selected)
        assertEquals("general", selected.agentId)
    }

    @Test fun expiredMemoryIsExcluded() {
        val store = InMemoryMemoryStore()
        store.put(MemoryEntry("old", "old", MemoryKind.NOTE, 1, expiresAtMs = 10))
        assertTrue(store.query(MemoryQuery(nowMs = 10)).isEmpty())
    }
}
