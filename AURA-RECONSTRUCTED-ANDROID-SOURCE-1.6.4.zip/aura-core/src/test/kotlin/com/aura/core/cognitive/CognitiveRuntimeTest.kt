package com.aura.core.cognitive

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class CognitiveRuntimeTest {
    @Test fun plannerFiltersCapabilities() {
        val p = TaskPlanner(setOf("vision", "speech"))
        assertEquals(listOf("vision", "speech"), p.plan("x", "inspect", listOf("vision", "hack", "speech")).steps.map { it.capability })
    }
    @Test fun policyDeniesSensitiveActionsByDefault() {
        assertTrue(ActionPolicy().decide(ActionClass.INFORM).allowed)
        assertFalse(ActionPolicy().decide(ActionClass.EXTERNAL_WRITE).allowed)
        assertFalse(ActionPolicy().decide(ActionClass.VEHICLE_CONTROL).allowed)
    }
    @Test fun contextIsBounded() {
        val c = ContextState(2); c.put("a", "1"); c.put("b", "2"); c.put("c", "3")
        assertEquals(mapOf("b" to "2", "c" to "3"), c.snapshot())
    }
}
