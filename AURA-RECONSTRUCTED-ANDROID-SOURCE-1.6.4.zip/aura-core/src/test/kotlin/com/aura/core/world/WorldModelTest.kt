package com.aura.core.world

import kotlin.test.Test
import kotlin.test.assertEquals

class WorldModelTest {
    @Test fun staleEntitiesAreExcluded() {
        val model = WorldModel(staleAfterNanos = 1_000_000_000L)
        model.upsert(WorldEntity(1, "car", 0.0, 0.0, 10.0, lastSeenNanos = 1_000_000_000L))
        assertEquals(1, model.snapshot(2_000_000_000L).entities.size)
        assertEquals(0, model.snapshot(2_000_000_001L).entities.size)
    }

    @Test fun projectionReturnsMetricDistance() {
        val (d, _) = WorldProjection.distanceAndBearing(3.0, 4.0)
        assertEquals(5.0, d)
    }
}
