package com.aura.core.perception

import kotlin.test.Test
import kotlin.test.assertEquals

class PerceptionHealthMonitorTest {
    @Test fun tracksCountersAndLatency() {
        val m = PerceptionHealthMonitor(2)
        m.received(); m.received(); m.dropped(); m.processed(10_000_000); m.processed(20_000_000)
        val s = m.snapshot()
        assertEquals(2, s.received)
        assertEquals(1, s.dropped)
        assertEquals(2, s.processed)
        assertEquals(15.0, s.averageLatencyMs)
    }
}
