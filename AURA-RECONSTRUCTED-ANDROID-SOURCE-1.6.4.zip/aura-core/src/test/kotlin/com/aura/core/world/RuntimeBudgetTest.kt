package com.aura.core.world

import kotlin.test.Test
import kotlin.test.assertEquals

class RuntimeBudgetTest {
    @Test fun lowPowerDisablesExpensiveFeatures() {
        val b = RuntimeBudgetPolicy.forMode(RuntimeMode.LOW_POWER)
        assertEquals(false, b.enableDepth)
        assertEquals(false, b.enableAudioEvents)
    }
}
