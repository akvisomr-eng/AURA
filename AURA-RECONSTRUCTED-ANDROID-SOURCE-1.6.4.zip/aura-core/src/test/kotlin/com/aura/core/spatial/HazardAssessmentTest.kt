package com.aura.core.spatial

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class HazardAssessmentTest {
    @Test fun criticalTtcIsDetected() {
        val a = HazardAssessor.assess(SpatialObservation(1, 10.0, 0.0, -8.0, 0.95))
        assertEquals(HazardLevel.CRITICAL, a.level)
        assertTrue((a.timeToCollisionSeconds ?: 99.0) < 1.5)
    }

    @Test fun nonClosingObjectIsClear() {
        val a = HazardAssessor.assess(SpatialObservation(1, 10.0, 0.0, 2.0, 0.95))
        assertEquals(HazardLevel.CLEAR, a.level)
    }
}
