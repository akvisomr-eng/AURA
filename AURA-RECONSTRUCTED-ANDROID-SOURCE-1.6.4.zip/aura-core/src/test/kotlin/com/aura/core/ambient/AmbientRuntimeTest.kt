package com.aura.core.ambient

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class AmbientRuntimeTest {
    @Test fun cameraRequiresPermission() {
        val router = AmbientEventRouter(AmbientPolicy(setOf(AmbientSource.CAMERA)))
        val event = AmbientEvent(AmbientSource.CAMERA, "frame", timestampMs = 1)
        assertNull(router.route(event))
    }
    @Test fun enabledVoiceRoutes() {
        val p = AmbientPolicy(setOf(AmbientSource.VOICE), setOf(AmbientPermission.MICROPHONE))
        val event = AmbientEvent(AmbientSource.VOICE, "utterance", timestampMs = 1)
        assertEquals(event, AmbientEventRouter(p).route(event))
    }
    @Test fun thermalSlowsRuntime() {
        assertEquals(500L, RuntimeDutyCycle().intervalMs(AmbientPolicy(thermalThrottled = true)))
    }
}
