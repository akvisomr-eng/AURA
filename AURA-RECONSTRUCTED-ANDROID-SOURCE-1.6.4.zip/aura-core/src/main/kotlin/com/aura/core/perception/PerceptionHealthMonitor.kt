package com.aura.core.perception

import kotlin.math.max

class PerceptionHealthMonitor(private val windowSize: Int = 30) {
    private val latencies = ArrayDeque<Long>()
    private var received = 0L
    private var processed = 0L
    private var dropped = 0L

    @Synchronized fun received() { received++ }
    @Synchronized fun dropped() { dropped++ }
    @Synchronized fun processed(latencyNanos: Long) {
        processed++
        latencies.add(max(0L, latencyNanos))
        while (latencies.size > windowSize) latencies.removeFirst()
    }

    @Synchronized fun snapshot() = Snapshot(
        received = received,
        processed = processed,
        dropped = dropped,
        averageLatencyMs = if (latencies.isEmpty()) 0.0
        else latencies.average() / 1_000_000.0
    )

    data class Snapshot(
        val received: Long,
        val processed: Long,
        val dropped: Long,
        val averageLatencyMs: Double
    )
}
