package com.aura.core.ambient

enum class AmbientSource { VOICE, NOTIFICATION, SENSOR, CAMERA, APP_CONTEXT, SYSTEM }
enum class AmbientPermission { MICROPHONE, CAMERA, NOTIFICATIONS, LOCATION, ACCESSIBILITY }
enum class AmbientPriority { LOW, NORMAL, HIGH, CRITICAL }

data class AmbientEvent(
    val source: AmbientSource,
    val type: String,
    val payload: Map<String, String> = emptyMap(),
    val timestampMs: Long,
    val priority: AmbientPriority = AmbientPriority.NORMAL
)

data class AmbientPolicy(
    val enabledSources: Set<AmbientSource> = emptySet(),
    val grantedPermissions: Set<AmbientPermission> = emptySet(),
    val batterySaver: Boolean = false,
    val thermalThrottled: Boolean = false
) {
    fun accepts(event: AmbientEvent): Boolean =
        event.source in enabledSources && when (event.source) {
            AmbientSource.VOICE -> AmbientPermission.MICROPHONE in grantedPermissions
            AmbientSource.CAMERA -> AmbientPermission.CAMERA in grantedPermissions
            AmbientSource.NOTIFICATION -> AmbientPermission.NOTIFICATIONS in grantedPermissions
            else -> true
        }
}

class AmbientEventRouter(private var policy: AmbientPolicy) {
    fun updatePolicy(newPolicy: AmbientPolicy) { policy = newPolicy }
    fun route(event: AmbientEvent): AmbientEvent? = if (policy.accepts(event)) event else null
}

class RuntimeDutyCycle(private val normalMs: Long = 100L, private val saverMs: Long = 500L) {
    fun intervalMs(policy: AmbientPolicy): Long =
        if (policy.batterySaver || policy.thermalThrottled) saverMs else normalMs
}
