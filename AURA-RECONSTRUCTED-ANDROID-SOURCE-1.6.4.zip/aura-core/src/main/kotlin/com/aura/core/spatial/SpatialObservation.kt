package com.aura.core.spatial

data class SpatialObservation(
    val trackId: Long,
    val distanceMeters: Double?,
    val lateralMeters: Double?,
    val relativeVelocityMps: Double?,
    val confidence: Double
)
