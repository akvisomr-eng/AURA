package com.aura.core.world

data class WorldEntity(
    val id: Long,
    val kind: String,
    val xMeters: Double,
    val yMeters: Double,
    val zMeters: Double,
    val vxMps: Double = 0.0,
    val vyMps: Double = 0.0,
    val vzMps: Double = 0.0,
    val confidence: Double = 0.0,
    val lastSeenNanos: Long = 0L
)

data class WorldSnapshot(
    val timestampNanos: Long,
    val entities: List<WorldEntity>
)

class WorldModel(private val staleAfterNanos: Long = 1_000_000_000L) {
    private val entities = LinkedHashMap<Long, WorldEntity>()

    fun upsert(entity: WorldEntity) { entities[entity.id] = entity }

    fun remove(id: Long) { entities.remove(id) }

    fun snapshot(nowNanos: Long): WorldSnapshot {
        val active = entities.values.filter { nowNanos - it.lastSeenNanos <= staleAfterNanos }
        return WorldSnapshot(nowNanos, active.toList())
    }

    fun clear() { entities.clear() }
}
