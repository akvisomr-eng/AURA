package com.aura.core.cognitive

data class TaskStep(val id: String, val capability: String, val input: Map<String, String> = emptyMap())
data class TaskPlan(val id: String, val goal: String, val steps: List<TaskStep>)

class TaskPlanner(private val allowed: Set<String>) {
    fun plan(id: String, goal: String, requestedCapabilities: List<String>): TaskPlan {
        val safe = requestedCapabilities.filter { it in allowed }.mapIndexed { i, c -> TaskStep("$id-$i", c) }
        return TaskPlan(id, goal, safe)
    }
}
