package com.aura.core.agent

/** Coordinates selection, bounded memory retrieval, and execution without coupling core to a model vendor. */
class AgentRuntime(
    private val registry: AgentRegistry,
    private val memory: MemoryStore
) {
    fun select(request: AgentRequest): AgentSelection? = registry.select(request)

    fun retrieveContext(query: MemoryQuery): List<MemoryEntry> = memory.query(query)

    fun remember(entry: MemoryEntry) {
        require(entry.text.length <= 16_384) { "memory entry too large" }
        require(entry.sensitivity != Sensitivity.HIGHLY_SENSITIVE) {
            "highly sensitive memory requires an explicit protected-storage implementation"
        }
        memory.put(entry)
    }
}
