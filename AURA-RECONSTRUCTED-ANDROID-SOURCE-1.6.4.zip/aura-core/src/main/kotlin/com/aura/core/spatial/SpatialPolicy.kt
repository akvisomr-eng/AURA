package com.aura.core.spatial

enum class SensorCapability { CAMERA, MICROPHONE, LOCATION, MOTION, DEPTH, EXTERNAL_STREAM }

data class PolicyDecision(val allowed: Boolean, val reason: String)

class SpatialPolicy(private val granted: Set<SensorCapability>) {
    fun authorize(capability: SensorCapability): PolicyDecision =
        if (capability in granted) PolicyDecision(true, "granted")
        else PolicyDecision(false, "permission-required")
}
