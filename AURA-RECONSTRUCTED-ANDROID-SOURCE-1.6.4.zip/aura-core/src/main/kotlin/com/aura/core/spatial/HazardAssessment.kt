package com.aura.core.spatial

import kotlin.math.abs

enum class HazardLevel { CLEAR, WATCH, WARNING, CRITICAL }

data class HazardAssessment(
    val level: HazardLevel,
    val timeToCollisionSeconds: Double?,
    val reason: String
)

object HazardAssessor {
    fun assess(
        observation: SpatialObservation,
        warningTtcSeconds: Double = 3.0,
        criticalTtcSeconds: Double = 1.5,
        minConfidence: Double = 0.55
    ): HazardAssessment {
        if (observation.confidence < minConfidence || observation.distanceMeters == null || observation.relativeVelocityMps == null)
            return HazardAssessment(HazardLevel.CLEAR, null, "insufficient-confidence-or-motion")

        val closing = observation.relativeVelocityMps < 0.0
        if (!closing) return HazardAssessment(HazardLevel.CLEAR, null, "not-closing")

        val ttc = observation.distanceMeters / abs(observation.relativeVelocityMps)
        return when {
            ttc <= criticalTtcSeconds -> HazardAssessment(HazardLevel.CRITICAL, ttc, "low-ttc")
            ttc <= warningTtcSeconds -> HazardAssessment(HazardLevel.WARNING, ttc, "elevated-ttc")
            else -> HazardAssessment(HazardLevel.WATCH, ttc, "closing-object")
        }
    }
}
