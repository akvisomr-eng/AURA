package com.aura.core.agent

/** Durable memory boundary. Implementations may use Room, SQLCipher, encrypted files, or a remote store. */
interface MemoryStore {
    fun put(entry: MemoryEntry)
    fun query(query: MemoryQuery): List<MemoryEntry>
    fun delete(id: String): Boolean
}

data class MemoryEntry(
    val id: String,
    val text: String,
    val kind: MemoryKind,
    val createdAtMs: Long,
    val expiresAtMs: Long? = null,
    val tags: Set<String> = emptySet(),
    val sensitivity: Sensitivity = Sensitivity.NORMAL
)

enum class MemoryKind { FACT, PREFERENCE, TASK, EPISODE, NOTE }
enum class Sensitivity { NORMAL, PRIVATE, HIGHLY_SENSITIVE }

data class MemoryQuery(
    val text: String? = null,
    val kinds: Set<MemoryKind> = emptySet(),
    val tags: Set<String> = emptySet(),
    val nowMs: Long = System.currentTimeMillis(),
    val includeSensitive: Boolean = false,
    val limit: Int = 20
)

class InMemoryMemoryStore : MemoryStore {
    private val entries = LinkedHashMap<String, MemoryEntry>()

    override fun put(entry: MemoryEntry) { entries[entry.id] = entry }

    override fun query(query: MemoryQuery): List<MemoryEntry> = entries.values.asSequence()
        .filter { it.expiresAtMs == null || it.expiresAtMs > query.nowMs }
        .filter { query.includeSensitive || it.sensitivity == Sensitivity.NORMAL }
        .filter { query.kinds.isEmpty() || it.kind in query.kinds }
        .filter { query.tags.isEmpty() || query.tags.all { tag -> tag in it.tags } }
        .filter { query.text.isNullOrBlank() || it.text.contains(query.text, ignoreCase = true) }
        .take(query.limit.coerceAtLeast(0))
        .toList()

    override fun delete(id: String): Boolean = entries.remove(id) != null
}
