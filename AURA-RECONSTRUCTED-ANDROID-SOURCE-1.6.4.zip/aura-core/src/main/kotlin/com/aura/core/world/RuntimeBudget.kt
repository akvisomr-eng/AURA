package com.aura.core.world

enum class RuntimeMode { LOW_POWER, BALANCED, REAL_TIME, MAX_ACCURACY }

data class RuntimeBudget(
    val targetInferenceHz: Double,
    val maxTrackedEntities: Int,
    val enableDepth: Boolean,
    val enableAudioEvents: Boolean
)

object RuntimeBudgetPolicy {
    fun forMode(mode: RuntimeMode): RuntimeBudget = when (mode) {
        RuntimeMode.LOW_POWER -> RuntimeBudget(5.0, 16, false, false)
        RuntimeMode.BALANCED -> RuntimeBudget(10.0, 32, true, false)
        RuntimeMode.REAL_TIME -> RuntimeBudget(15.0, 64, true, true)
        RuntimeMode.MAX_ACCURACY -> RuntimeBudget(24.0, 128, true, true)
    }
}
