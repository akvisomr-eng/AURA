package com.aura.core.agent

/** A vendor/model-neutral capability an agent can provide. */
data class Capability(
    val id: String,
    val description: String = "",
    val risk: RiskLevel = RiskLevel.LOW,
    val tags: Set<String> = emptySet()
)

enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }

data class AgentDescriptor(
    val id: String,
    val capabilities: Set<Capability>,
    val priority: Int = 0,
    val enabled: Boolean = true
)

data class AgentRequest(
    val taskId: String,
    val intent: String,
    val requiredCapabilities: Set<String> = emptySet(),
    val preferredAgentId: String? = null,
    val maxRisk: RiskLevel = RiskLevel.MEDIUM,
    val metadata: Map<String, String> = emptyMap()
)

data class AgentSelection(
    val agentId: String,
    val score: Int,
    val matchedCapabilities: Set<String>
)

class AgentRegistry {
    private val agents = LinkedHashMap<String, AgentDescriptor>()

    fun register(agent: AgentDescriptor) { agents[agent.id] = agent }
    fun unregister(agentId: String) { agents.remove(agentId) }
    fun snapshot(): List<AgentDescriptor> = agents.values.toList()

    fun select(request: AgentRequest): AgentSelection? {
        return agents.values.asSequence()
            .filter { it.enabled }
            .mapNotNull { agent ->
                val matched = request.requiredCapabilities.intersect(agent.capabilities.map { it.id }.toSet())
                if (matched.size != request.requiredCapabilities.size) return@mapNotNull null
                if (agent.capabilities.any { it.risk.ordinal > request.maxRisk.ordinal && it.id in request.requiredCapabilities }) return@mapNotNull null
                val preference = if (agent.id == request.preferredAgentId) 1000 else 0
                AgentSelection(agent.id, preference + matched.size * 100 + agent.priority, matched)
            }
            .maxByOrNull { it.score }
    }
}
