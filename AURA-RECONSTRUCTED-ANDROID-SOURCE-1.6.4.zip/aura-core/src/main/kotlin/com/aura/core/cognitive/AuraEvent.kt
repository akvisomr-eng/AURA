package com.aura.core.cognitive

data class AuraEvent(
    val type: String,
    val timestampMs: Long,
    val payload: Map<String, String> = emptyMap(),
    val priority: Int = 0
)
