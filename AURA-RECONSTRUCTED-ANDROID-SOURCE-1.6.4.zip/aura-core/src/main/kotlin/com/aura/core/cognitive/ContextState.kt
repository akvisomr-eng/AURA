package com.aura.core.cognitive

class ContextState(private val maxEntries: Int = 128) {
    private val values = LinkedHashMap<String, String>()
    @Synchronized fun put(key: String, value: String) { values[key] = value; while (values.size > maxEntries) values.remove(values.entries.first().key) }
    @Synchronized fun get(key: String): String? = values[key]
    @Synchronized fun snapshot(): Map<String, String> = values.toMap()
}
