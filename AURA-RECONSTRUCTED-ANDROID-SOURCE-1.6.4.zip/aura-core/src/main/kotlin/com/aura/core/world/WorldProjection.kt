package com.aura.core.world

import kotlin.math.hypot

/** Projects camera-relative observations into a stable local world frame. */
object WorldProjection {
    fun distanceAndBearing(xMeters: Double, zMeters: Double): Pair<Double, Double> {
        val distance = hypot(xMeters, zMeters)
        val bearingRadians = kotlin.math.atan2(xMeters, zMeters)
        return distance to bearingRadians
    }
}
