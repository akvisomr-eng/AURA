package com.aura.core.spatial

enum class ComputeTarget { CPU, GPU, NPU }

data class DeviceCapabilities(
    val hasCamera: Boolean,
    val hasImu: Boolean,
    val hasGnss: Boolean,
    val hasDepthSensor: Boolean,
    val supportsArCoreDepth: Boolean,
    val computeTargets: Set<ComputeTarget>
)

class DeviceCapabilityRegistry(private val capabilities: DeviceCapabilities) {
    fun current(): DeviceCapabilities = capabilities
    fun bestDepthBackend(): String = when {
        capabilities.supportsArCoreDepth -> "ARCORE_DEPTH"
        capabilities.hasDepthSensor -> "HARDWARE_DEPTH"
        else -> "MONOCULAR_DEPTH_FALLBACK"
    }
}
