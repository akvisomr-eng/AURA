package com.aura.core.spatial

import kotlin.math.abs

class ObjectMotionEstimator(private val maxDeltaSeconds: Double = 0.5) {
    private data class Sample(val distance: Double, val lateral: Double, val timeNanos: Long)
    private val previous = HashMap<Long, Sample>()

    fun update(observation: SpatialObservation, timestampNanos: Long): SpatialObservation {
        val d = observation.distanceMeters ?: return observation
        val l = observation.lateralMeters ?: 0.0
        val old = previous.put(observation.trackId, Sample(d, l, timestampNanos)) ?: return observation
        val dt = (timestampNanos - old.timeNanos) / 1_000_000_000.0
        if (dt <= 0.0 || dt > maxDeltaSeconds) return observation
        return observation.copy(
            relativeVelocityMps = (d - old.distance) / dt,
            lateralMeters = l
        )
    }

    fun forget(trackId: Long) { previous.remove(trackId) }
    fun clear() { previous.clear() }
}
