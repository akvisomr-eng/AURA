package com.aura.core.cognitive

class EventBus(private val clockMs: () -> Long = { System.currentTimeMillis() }) {
    private val subscribers = mutableMapOf<String, MutableList<(AuraEvent) -> Unit>>()
    fun subscribe(type: String, handler: (AuraEvent) -> Unit) { subscribers.getOrPut(type) { mutableListOf() }.add(handler) }
    fun publish(type: String, payload: Map<String, String> = emptyMap(), priority: Int = 0) {
        val event = AuraEvent(type, clockMs(), payload, priority)
        subscribers[type]?.toList()?.forEach { it(event) }
    }
}
