package com.aura.core.cognitive

enum class ActionClass { OBSERVE, INFORM, NOTIFY, OPEN_APP, EXTERNAL_WRITE, VEHICLE_CONTROL }

data class PolicyDecision(val allowed: Boolean, val reason: String)

class ActionPolicy(private val explicitlyAuthorized: Set<ActionClass> = emptySet()) {
    fun decide(action: ActionClass): PolicyDecision = when (action) {
        ActionClass.OBSERVE, ActionClass.INFORM, ActionClass.NOTIFY -> PolicyDecision(true, "safe-default")
        else -> if (action in explicitlyAuthorized) PolicyDecision(true, "explicitly-authorized") else PolicyDecision(false, "authorization-required")
    }
}
