#!/usr/bin/env bash
set -euo pipefail

# Portable build bootstrap for AURA. Run this on a machine with network access.
# It intentionally does not install anything silently with root privileges.

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: JDK 17+ is required." >&2; exit 1
fi

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle 8.9+ is required. Install Gradle or use the included GitHub Actions workflow." >&2
  exit 2
fi

if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: ANDROID_HOME/ANDROID_SDK_ROOT is not configured." >&2; exit 3
fi

SDK="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
if [[ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]]; then
  echo "ERROR: Android command-line tools are missing at $SDK/cmdline-tools/latest/bin/sdkmanager" >&2
  exit 4
fi

"$SDK/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

gradle test --no-daemon
gradle lint --no-daemon
gradle assembleRelease --no-daemon
gradle bundleRelease --no-daemon

echo "BUILD PASS"
echo "APK: app/build/outputs/apk/release/"
echo "AAB: app/build/outputs/bundle/release/"
