#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle is not installed. Use GitHub Actions or install Gradle 8.9+." >&2
  exit 2
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo "ERROR: Android SDK is not configured (ANDROID_HOME/ANDROID_SDK_ROOT)." >&2
  exit 3
fi
gradle projects --no-daemon
gradle test --no-daemon
gradle lint --no-daemon
gradle assembleRelease --no-daemon
gradle bundleRelease --no-daemon
echo "BUILD_PASS"
