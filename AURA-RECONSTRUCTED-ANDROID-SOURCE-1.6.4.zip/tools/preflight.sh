#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PASS=0; WARN=0
check(){ if command -v "$1" >/dev/null 2>&1; then echo "PASS $1: $(command -v "$1")"; PASS=$((PASS+1)); else echo "WARN $1: not installed"; WARN=$((WARN+1)); fi; }
echo "AURA 1.6 reconstructed build preflight"
check java
check gradle
check adb
if [ -n "${ANDROID_HOME:-}" ]; then echo "PASS ANDROID_HOME=$ANDROID_HOME"; PASS=$((PASS+1)); else echo "WARN ANDROID_HOME: not set"; WARN=$((WARN+1)); fi
if [ -d "$ROOT/app" ] && [ -d "$ROOT/aura-core" ] && [ -f "$ROOT/settings.gradle.kts" ]; then echo "PASS project structure"; PASS=$((PASS+1)); else echo "FAIL project structure"; exit 2; fi
if command -v kotlinc >/dev/null 2>&1; then rm -rf /tmp/aura-preflight-classes; mkdir -p /tmp/aura-preflight-classes; kotlinc "$ROOT/aura-core/src/main/kotlin" -d /tmp/aura-preflight-classes/aura-core.jar && echo "PASS Kotlin core compilation" || { echo "FAIL Kotlin core compilation"; exit 3; }; else echo "WARN Kotlin compiler unavailable"; WARN=$((WARN+1)); fi
echo "SUMMARY pass=$PASS warn=$WARN"
