# AURA 1.6.2 — Android build gate

The previous blocker was the execution environment: it has Java/Kotlin but no Gradle, Android SDK, or ADB. The source itself also contained two `Theme.Aura` resource definitions, which has now been removed.

## Fastest route: GitHub Actions

Push this project to a Git repository. `.github/workflows/android-build.yml` installs JDK 17, Android API 35/build-tools 35.0.0, Gradle 8.9, runs tests/lint, and produces both APK and AAB artifacts.

## Local route

Requirements:
- JDK 17
- Gradle 8.9+
- Android SDK command-line tools
- Android platform 35
- Android build-tools 35.0.0
- ADB for device testing

Then:

```bash
./tools/bootstrap-android-build.sh
```

After a successful build:

```bash
adb install -r app/build/outputs/apk/release/app-release.apk
adb shell am start -n com.aura.app/.MainActivity
```

The release APK/AAB must be signed with the production keystore before Play Console upload.
