# AURA — Reconstructed Android Source

Autonomously reconstructed from the available AURA FINAL DEPLOY PACK. This is a new source-of-truth scaffold, not the historical canonical project.

Included: perception 1.0.2, spatial 1.1, world model 1.2, cognitive 1.3, agent/memory 1.4, ambient 1.5, plus a minimal Android shell.

Release status: **not a signed production APK/AAB**. The supplied material did not contain the original Android project, and this environment has no Android SDK/Gradle distribution or production signing key.

Before production: install Android SDK/Gradle, resolve dependencies, run tests/lint, device tests, integrate concrete providers, configure external signing, then build signed AAB/APK.
