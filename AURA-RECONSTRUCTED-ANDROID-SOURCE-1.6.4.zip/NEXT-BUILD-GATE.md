# AURA Next Build Gate

This reconstructed source is the current source-of-truth generated from the available AURA patch/deploy material.

## Local Android build host
Requires JDK 17, Android SDK 35, Gradle (or Gradle Wrapper), and an Android device/emulator for smoke tests.

```bash
./gradlew test
./gradlew lint
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
```

## First-run smoke test
1. Launch AURA.
2. Confirm runtime status screen appears.
3. Confirm camera/microphone are NOT accessed before consent.
4. Grant permissions.
5. Relaunch and confirm permission state is retained.
6. Revoke permissions in Android Settings and confirm AURA reports the change.

## Production gate
Do not publish until Android build, lint, tests, device smoke tests, signing, and release artifact checks pass.
