package com.aura.app.perception

import android.graphics.Bitmap
import java.util.concurrent.atomic.AtomicReference

/** Single-slot frame pool: newest frame wins; no unbounded bitmap queue. */
class FramePool {
    private val latest = AtomicReference<Bitmap?>(null)

    fun offer(bitmap: Bitmap) {
        latest.getAndSet(bitmap)?.let { old ->
            if (!old.isRecycled) old.recycle()
        }
    }

    fun acquire(): Bitmap? = latest.getAndSet(null)

    fun clear() {
        latest.getAndSet(null)?.let { if (!it.isRecycled) it.recycle() }
    }
}
